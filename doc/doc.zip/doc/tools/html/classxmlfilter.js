var classxmlfilter =
[
    [ "startup", "classxmlfilter.html#ae32a78d781bd1a5cabcb4a254b9c5381", null ],
    [ "main", "classxmlfilter.html#aff321bd6de0795e1437460e75322a2aa", null ],
    [ "version", "classxmlfilter.html#ad4840bad594536b6b6d3bdf4acf6cd79", null ],
    [ "xmlHelp", "classxmlfilter.html#accbe98c45559f518d59d9f3729c4f834", null ],
    [ "Opts", "classxmlfilter.html#a42e42ac074afc2d373c982bbe3265864", null ],
    [ "Params", "classxmlfilter.html#a5cce78bf320b38143ef55f2e9e5da4c6", null ],
    [ "DEFAULT_XSLFILE", "classxmlfilter.html#ae099af81099432b33d6c0b249da3f6d2", null ],
    [ "DEFAULT_CONFIG", "classxmlfilter.html#a0b57390175f002644d21ab4b7ec6898e", null ],
    [ "FILETITLE", "classxmlfilter.html#a2159f6c2640f278b3ddb302f03295fe0", null ],
    [ "engine", "classxmlfilter.html#a24ce3f1eef571d6c60d950059f81b5cb", null ],
    [ "xslFileN", "classxmlfilter.html#a83e683778ed8a231cde924fc286a6056", null ]
];